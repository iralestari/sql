sqlite> SELECT CategoryName
   ...> FROM Category
   ...> ORDER BY CategoryName ASC;
Beverages
Condiments
Confections
Dairy Products
Grains/Cereals
Meat/Poultry
Produce
Seafood
sqlite>